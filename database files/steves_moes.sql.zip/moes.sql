-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 26, 2017 at 07:22 PM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moes`
--
CREATE DATABASE IF NOT EXISTS `moes` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `moes`;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `order_date` date DEFAULT NULL,
  `order_number` int(11) DEFAULT NULL,
  `order_cost` float(10,2) DEFAULT NULL,
  `autoship` tinyint(4) DEFAULT NULL,
  `confirmation` tinyint(1) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `carts_products`
--

CREATE TABLE `carts_products` (
  `cart_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `contact` varchar(255) NOT NULL,
  `business` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`contact`, `business`, `address`, `phone`, `email`, `login`, `password`, `id`) VALUES
('Customer', 'Business', 'Address', 'phone', '93kaflka@hotmail.com', '', '', 1),
('asdfa', 'asfd', 'asf', 'adsf', 'asdf', '', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers_carts`
--

CREATE TABLE `customers_carts` (
  `customer_id` int(255) NOT NULL,
  `cart_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `name` varchar(255) DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`name`, `price`, `id`) VALUES
('23', 22.00, 1),
('23', 22.00, 2),
('23', 22.00, 3),
('23', 22.00, 4),
('23', 22.00, 5),
('23', 22.00, 6),
('30_gallon_keg', 30.00, 7),
('60_gallon_keg', 40.00, 8),
('15_gallon_keg', 22.00, 9),
('60_gallon_keg', 40.00, 10),
('15_gallon_keg', 22.00, 11),
('30_gallon_keg', 150.00, 12),
('60_gallon_keg', 200.00, 13),
('60_gallon_keg', 200.00, 14),
('60_gallon_keg', 200.00, 15),
('60_gallon_keg', 200.00, 16),
('60_gallon_keg', 200.00, 17),
('60_gallon_keg', 200.00, 18),
('60_gallon_keg', 200.00, 19),
('15_gallon_keg', 22.00, 20),
('15_gallon_keg', 22.00, 21),
('15_gallon_keg', 22.00, 22),
('15_gallon_keg', 22.00, 23),
('15_gallon_keg', 22.00, 24),
('15_gallon_keg', 22.00, 25),
('15_gallon_keg', 22.00, 26),
('15_gallon_keg', 22.00, 27),
('15_gallon_keg', 22.00, 28),
('15_gallon_keg', 22.00, 29),
('15_gallon_keg', 22.00, 30),
('15_gallon_keg', 22.00, 31),
('15_gallon_keg', 22.00, 32),
('15_gallon_keg', 22.00, 33),
('15_gallon_keg', 22.00, 34),
('60_gallon_keg', 200.00, 35),
('60_gallon_keg', 200.00, 36),
('60_gallon_keg', 200.00, 37),
('60_gallon_keg', 200.00, 38),
('60_gallon_keg', 200.00, 39),
('60_gallon_keg', 200.00, 40),
('60_gallon_keg', 200.00, 41),
('60_gallon_keg', 200.00, 42),
('15_gallon_keg', 100.00, 43),
('30_gallon_keg', 150.00, 44),
('60_gallon_keg', 200.00, 45),
('60_gallon_keg', 200.00, 46),
('60_gallon_keg', 200.00, 47),
('60_gallon_keg', 200.00, 48),
('60_gallon_keg', 200.00, 49),
('60_gallon_keg', 200.00, 50),
('60_gallon_keg', 200.00, 51),
('60_gallon_keg', 200.00, 52),
('60_gallon_keg', 200.00, 53),
('60_gallon_keg', 200.00, 54),
('60_gallon_keg', 200.00, 55),
('60_gallon_keg', 200.00, 56),
('60_gallon_keg', 200.00, 57),
('60_gallon_keg', 200.00, 58),
('15_gallon_keg', 22.00, 59),
('15_gallon_keg', 22.00, 60),
('15_gallon_keg', 22.00, 61),
('15_gallon_keg', 22.00, 62),
('15_gallon_keg', 22.00, 63),
('15_gallon_keg', 22.00, 64),
('5_gallon_keg', 100.00, 65),
('5_gallon_keg', 100.00, 66),
('5_gallon_keg', 100.00, 67),
('5_gallon_keg', 100.00, 68),
('5_gallon_keg', 100.00, 69),
('5_gallon_keg', 100.00, 70),
('5_gallon_keg', 100.00, 71),
('5_gallon_keg', 100.00, 72),
('5_gallon_keg', 100.00, 73),
('5_gallon_keg', 100.00, 74),
('5_gallon_keg', 100.00, 75),
('5_gallon_keg', 100.00, 76),
('5_gallon_keg', 100.00, 77),
('5_gallon_keg', 100.00, 78),
('5_gallon_keg', 100.00, 79),
('5_gallon_keg', 100.00, 80),
('5_gallon_keg', 100.00, 81),
('5_gallon_keg', 100.00, 82),
('5_gallon_keg', 100.00, 83),
('5_gallon_keg', 100.00, 84),
('5_gallon_keg', 100.00, 85),
('5_gallon_keg', 100.00, 86),
('5_gallon_keg', 100.00, 87);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `carts_products`
--
ALTER TABLE `carts_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `carts_products`
--
ALTER TABLE `carts_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
